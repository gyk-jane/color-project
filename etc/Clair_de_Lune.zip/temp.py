# %%
import music21 as m
import pandas as pd
import re

cdl = m.converter.parse('Clair_de_Lune.mid')
# creating a dataframe of all notes, chords, and rests for analysis
col_names = ['type', 'note(s)', 'duration_type', 'duration_quarterLength', 'tie', 'quarterLength']
type_list = []
notes_list = []
duration_list = []
duration_qLength = []
tie_list = []
qLength_list = []
for x in cdl.recurse().notesAndRests:
    if (x.isNote):
        type_list.append('note')
        notes_list.append(str(x.pitch).replace('-', ''))
        duration_list.append(x.duration.type)
        duration_qLength.append(x.duration.quarterLength)
        tie_list.append(x.tie)
        qLength_list.append(x.quarterLength)
    if (x.isChord):
        type_list.append('chord')
        
        # take only the notes which make up the chord
        temp_str = str(x).replace('<music21.chord.Chord ', '')
        temp_str = temp_str.replace('>', '')
        temp_str = temp_str.replace('-', '')
        x_str = temp_str.replace(' ', ',')
        notes_list.append(x_str)
        duration_list.append(x.duration.type)
        duration_qLength.append(x.duration.quarterLength)
        tie_list.append(x.tie)
        qLength_list.append(x.quarterLength)
    if (x.isRest):
        type_list.append('rest')
        notes_list.append('')
        duration_list.append(x.duration.type)
        duration_qLength.append(x.duration.quarterLength)
        tie_list.append(x.tie)
        qLength_list.append(x.quarterLength)
zippedList =  list(zip(type_list, notes_list, duration_list, duration_qLength, tie_list, qLength_list))
df_orgNotes = pd.DataFrame(zippedList, columns = col_names) 

df_orgNotes.to_html('Clair_de_Lune.html', index=False)