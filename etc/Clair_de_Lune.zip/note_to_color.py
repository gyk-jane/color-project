
#%%
# the goal is to get a list of RGB values for each HEX code associated with a color from the RYB color wheel

import csv
import webcolors
import matplotlib.pyplot as plt
import numpy as np

color_note = []
with open('music_color.csv') as file:
    reader = csv.reader(file, lineterminator = '\n')
    color_note = list(reader)

# note there are 7 octaves in total. following will calculate the different pitch/shades
# integerRGB is a namedtuple() so we can call each of its contents array-style
# @param int type
def music_and_color(octave, percentage):
    hex_note = []
    if percentage == 0:
        for idx, val in enumerate(color_note):
            if idx == 0:
                continue
            else:
                hex_to_rgb = webcolors.hex_to_rgb(str(val[0]))
                hex_note.append([(hex_to_rgb[0], hex_to_rgb[1], hex_to_rgb[2]), val[1]+ str(octave), val[2]+ str(octave)])
    else:
        for idx, val in enumerate(color_note):
            if idx==0:
                continue
            else:
                hex_to_rgb = webcolors.hex_to_rgb(str(val[0]))
                # octave lower than 4
                if octave < 4:
                    # construct a new webcolors.IntegerRGB object by multiplying each RGB factor by the |percentage|
                    tup_temp = (int(hex_to_rgb[0]*percentage), int(hex_to_rgb[1]*percentage), int(hex_to_rgb[2]*percentage))
                    hex_note.append([tup_temp, val[1]+str(octave), val[2]+str(octave)])
                else:
                    # construct a new webcolors.IntegerRGB object by using the formula on my paper
                    subtract_rgb = (abs(hex_to_rgb[0]-255), abs(hex_to_rgb[1]-255), abs(hex_to_rgb[2]-255))
                    mult_rgb = (int(subtract_rgb[0]*percentage), int(subtract_rgb[1]*percentage), int(subtract_rgb[2]*percentage))
                    tup_temp = (mult_rgb[0]+hex_to_rgb[0], mult_rgb[1]+hex_to_rgb[1], mult_rgb[2]+hex_to_rgb[2])
                    hex_note.append([tup_temp, val[1]+str(octave), val[2]+str(octave)])
    return hex_note
# %%
# the goal is to get a complete chart of all the colors associated with the colors and their various pitches/shades

octave_1 = music_and_color(1, 0.3)
octave_2 = music_and_color(2, 0.6)
octave_3 = music_and_color(3, 0.9)
octave_4 = music_and_color(4,0) 
octave_5 = music_and_color(5, 0.3)
octave_6 = music_and_color(6, 0.6)
octave_7 = music_and_color(7, 0.9)

columns = ('G', 'D', 'A', 'E/Fb', 'B/Cb', 'F#', 'C#/Db', 'G#/Ab', 'D#/Eb', 'A#/Bb', 'E#/Bb', 'B#/C')
rows = [1,2,3,4,5,6,7]

colors = [[webcolors.rgb_to_hex(i[0]) for i in octave_1], [webcolors.rgb_to_hex(i[0]) for i in octave_2], [webcolors.rgb_to_hex(i[0]) for i in octave_3], [webcolors.rgb_to_hex(i[0]) for i in octave_4],
[webcolors.rgb_to_hex(i[0]) for i in octave_5], [webcolors.rgb_to_hex(i[0]) for i in octave_6], [webcolors.rgb_to_hex(i[0]) for i in octave_7]]

fig, ax = plt.subplots()
ax.axis('tight')
ax.axis('off')
the_table = ax.table(cellColours=colors, colLabels=columns, rowLabels=rows)

plt.show()
# %%
